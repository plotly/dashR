library(testthat)
library(dash)

test_check("dash")
